# Weapon Showcase (Forge 1.18.2)

Mod original, somente de cliente. Aperte **R** (configurável) para inspecionar o item da mão principal
com uma animação em primeira pessoa: Vitrine, Giro, Cambalhota, Arremesso, Floreio e Examinar.

- Menu de configuração: Mods > Weapon Showcase > Config (ou a tecla "Abrir configurações", sem atalho por padrão).
- Teclas em Opções > Controles > Weapon Showcase: Inspecionar (R), Próxima animação, Abrir configurações.
- Opções: animação, aleatória, velocidade, intensidade, só ferramentas/armas, cancelar ao atacar, mão vazia, pré-visualização, FOV da mão (30 a 110) e campo de visão do mundo (30 a 160).

Escrito do zero para o 1.18.2; não usa código nem assets de outros mods. Licença MIT.
