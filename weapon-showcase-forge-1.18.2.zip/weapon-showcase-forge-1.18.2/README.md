# Weapon Showcase (Forge 1.18.2)

Mod original, somente de cliente. Aperte **R** (configurável) para inspecionar o item da mão principal com uma
animação em primeira pessoa, em loop, no estilo das inspeções de faca do CS.

- **R**: inicia. **R de novo**: reinicia com outra animação, misturando a partir da posição atual.
- **Shift + R**: para. Atacar, usar o item, trocar de slot ou abrir um menu também param.
- Animações: Giro da lâmina, Vitrine, Arremesso, Cambalhota, Leque, Examinar, Helicóptero e Balanço.
- O braço do personagem é desenhado segurando o item (vanilla só mostra o braço com a mão vazia).
- Menu: Mods > Weapon Showcase > Config (ou a tecla "Abrir configurações", sem atalho por padrão).
- Página "Animação": animação, aleatória, velocidade (0,5x a 10x), intensidade, repetir sempre, mostrar braço,
  só ferramentas/armas, cancelar ao atacar, mão vazia.
- Página "Mãos e visão": posição X e Y das mãos na tela, espaço entre as mãos, FOV da mão (30 a 110),
  campo de visão do mundo (30 a 160).

Escrito do zero para o 1.18.2; não usa código nem assets de outros mods. Licença MIT.
