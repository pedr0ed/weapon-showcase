package dev.weaponshowcase;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.IExtensionPoint;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.network.NetworkConstants;

/** Client-only mod: on a dedicated server this class loads and does nothing. */
@Mod("weaponshowcase")
public final class WeaponShowcase {
   public WeaponShowcase() {
      // Purely client side: servers never require it, and it never requires the server to have it.
      ModLoadingContext.get().registerExtensionPoint(
         IExtensionPoint.DisplayTest.class,
         () -> new IExtensionPoint.DisplayTest(() -> NetworkConstants.IGNORESERVERONLY, (remote, isServer) -> true)
      );

      if (FMLEnvironment.dist == Dist.CLIENT) {
         WeaponShowcaseClient.init();
      }
   }
}
