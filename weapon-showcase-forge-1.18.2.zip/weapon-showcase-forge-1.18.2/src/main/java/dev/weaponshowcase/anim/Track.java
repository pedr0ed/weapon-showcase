package dev.weaponshowcase.anim;

/**
 * A seamlessly looping keyframe curve. Each keyframe is {time, tx, ty, tz, rx, ry, rz, ra} with time in 0..1.
 * The last keyframe must equal the first, except that angles may have advanced by whole turns (a spin). Values are
 * blended with cubic Hermite splines whose tangents wrap around, so the motion has no hitch at the loop point.
 */
public final class Track {
   private static final int CHANNELS = 7;
   private final double[] times;
   private final double[][] values;
   private final double[][] tangents;
   private final double[] drift = new double[CHANNELS];

   public Track(double[][] keyframes) {
      int n = keyframes.length;
      this.times = new double[n];
      this.values = new double[n][CHANNELS];
      this.tangents = new double[n][CHANNELS];
      for (int i = 0; i < n; i++) {
         this.times[i] = keyframes[i][0];
         System.arraycopy(keyframes[i], 1, this.values[i], 0, CHANNELS);
      }

      for (int c = 0; c < CHANNELS; c++) {
         this.drift[c] = this.values[n - 1][c] - this.values[0][c];
      }

      for (int i = 1; i < n - 1; i++) {
         double span = this.times[i + 1] - this.times[i - 1];
         for (int c = 0; c < CHANNELS; c++) {
            this.tangents[i][c] = (this.values[i + 1][c] - this.values[i - 1][c]) / span;
         }
      }

      double wrapSpan = this.times[1] + 1.0 - this.times[n - 2];
      for (int c = 0; c < CHANNELS; c++) {
         double m = (this.values[1][c] - (this.values[n - 2][c] - this.drift[c])) / wrapSpan;
         this.tangents[0][c] = m;
         this.tangents[n - 1][c] = m;
      }
   }

   /** Writes the pose after {@code cycles} loops (fractions allowed, never negative) into {@code out}. */
   public Pose evaluate(double cycles, Pose out) {
      double whole = Math.floor(Math.max(0.0, cycles));
      double u = Math.max(0.0, cycles) - whole;
      int last = this.times.length - 1;
      int i = 0;
      while (i < last - 1 && u > this.times[i + 1]) {
         i++;
      }

      double h = this.times[i + 1] - this.times[i];
      double s = h <= 0.0 ? 1.0 : (u - this.times[i]) / h;
      s = Math.max(0.0, Math.min(1.0, s));
      double s2 = s * s;
      double s3 = s2 * s;
      double h00 = 2.0 * s3 - 3.0 * s2 + 1.0;
      double h10 = s3 - 2.0 * s2 + s;
      double h01 = -2.0 * s3 + 3.0 * s2;
      double h11 = s3 - s2;
      double[] r = new double[CHANNELS];
      for (int c = 0; c < CHANNELS; c++) {
         r[c] = h00 * this.values[i][c]
            + h10 * h * this.tangents[i][c]
            + h01 * this.values[i + 1][c]
            + h11 * h * this.tangents[i + 1][c]
            + whole * this.drift[c];
      }

      out.tx = (float)r[0];
      out.ty = (float)r[1];
      out.tz = (float)r[2];
      // Angles are reduced here so they never grow large enough to lose float precision in a long session.
      out.rx = (float)(r[3] % 360.0);
      out.ry = (float)(r[4] % 360.0);
      out.rz = (float)(r[5] % 360.0);
      out.ra = (float)(r[6] % 360.0);
      return out;
   }
}
