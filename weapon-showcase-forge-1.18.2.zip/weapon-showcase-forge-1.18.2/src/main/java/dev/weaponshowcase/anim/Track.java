package dev.weaponshowcase.anim;

/**
 * Smooth keyframe curve. Each keyframe is {time, tx, ty, tz, rx, ry, rz} with time in 0..1.
 * Values are blended with cubic Hermite splines; the curve starts and ends at rest.
 */
public final class Track {
   private static final int CHANNELS = 6;
   private final double[] times;
   private final double[][] values;
   private final double[][] tangents;

   public Track(double[][] keyframes) {
      int n = keyframes.length;
      this.times = new double[n];
      this.values = new double[n][CHANNELS];
      this.tangents = new double[n][CHANNELS];
      for (int i = 0; i < n; i++) {
         this.times[i] = keyframes[i][0];
         System.arraycopy(keyframes[i], 1, this.values[i], 0, CHANNELS);
      }

      for (int i = 1; i < n - 1; i++) {
         double span = this.times[i + 1] - this.times[i - 1];
         for (int c = 0; c < CHANNELS; c++) {
            this.tangents[i][c] = (this.values[i + 1][c] - this.values[i - 1][c]) / span;
         }
      }
   }

   /** Writes the pose at normalised time {@code t} (clamped to 0..1) into {@code out}. */
   public Pose evaluate(double t, Pose out) {
      double time = Math.max(0.0, Math.min(1.0, t));
      int last = this.times.length - 1;
      int i = 0;
      while (i < last - 1 && time > this.times[i + 1]) {
         i++;
      }

      double h = this.times[i + 1] - this.times[i];
      double s = h <= 0.0 ? 1.0 : (time - this.times[i]) / h;
      s = Math.max(0.0, Math.min(1.0, s));
      double s2 = s * s;
      double s3 = s2 * s;
      double h00 = 2.0 * s3 - 3.0 * s2 + 1.0;
      double h10 = s3 - 2.0 * s2 + s;
      double h01 = -2.0 * s3 + 3.0 * s2;
      double h11 = s3 - s2;
      double[] r = new double[CHANNELS];
      for (int c = 0; c < CHANNELS; c++) {
         r[c] = h00 * this.values[i][c] + h10 * h * this.tangents[i][c] + h01 * this.values[i + 1][c] + h11 * h * this.tangents[i + 1][c];
      }

      out.tx = (float)r[0];
      out.ty = (float)r[1];
      out.tz = (float)r[2];
      out.rx = (float)r[3];
      out.ry = (float)r[4];
      out.rz = (float)r[5];
      return out;
   }
}
