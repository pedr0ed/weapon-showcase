package dev.weaponshowcase.anim;

/** A hand offset in camera space: translation in blocks, rotation in degrees. */
public final class Pose {
   public float tx;
   public float ty;
   public float tz;
   public float rx;
   public float ry;
   public float rz;

   public Pose scale(float translation, float rotation) {
      this.tx *= translation;
      this.ty *= translation;
      this.tz *= translation;
      this.rx *= rotation;
      this.ry *= rotation;
      this.rz *= rotation;
      return this;
   }

   public Pose fade(float amount) {
      return this.scale(amount, amount);
   }
}
