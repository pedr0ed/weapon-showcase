package dev.weaponshowcase.anim;

/**
 * A hand offset in camera space: translation in blocks, rotation in degrees.
 * rx/ry/rz are tilt, turn and roll around the camera axes; ra rolls the item around its own long axis.
 */
public final class Pose {
   public float tx;
   public float ty;
   public float tz;
   public float rx;
   public float ry;
   public float rz;
   public float ra;

   public Pose set(Pose other) {
      this.tx = other.tx;
      this.ty = other.ty;
      this.tz = other.tz;
      this.rx = other.rx;
      this.ry = other.ry;
      this.rz = other.rz;
      this.ra = other.ra;
      return this;
   }

   public Pose clear() {
      this.tx = this.ty = this.tz = this.rx = this.ry = this.rz = this.ra = 0.0F;
      return this;
   }

   public Pose scale(float translation, float rotation) {
      this.tx *= translation;
      this.ty *= translation;
      this.tz *= translation;
      this.rx *= rotation;
      this.ry *= rotation;
      this.rz *= rotation;
      this.ra *= rotation;
      return this;
   }

   /** Wraps every angle into (-180, 180] so poses can be blended along the shortest arc. */
   public Pose normalize() {
      this.rx = wrap(this.rx);
      this.ry = wrap(this.ry);
      this.rz = wrap(this.rz);
      this.ra = wrap(this.ra);
      return this;
   }

   /** Sets this pose to a blend of {@code from} and {@code to}; angles take the shortest way round. */
   public Pose blend(Pose from, Pose to, float t) {
      this.tx = from.tx + (to.tx - from.tx) * t;
      this.ty = from.ty + (to.ty - from.ty) * t;
      this.tz = from.tz + (to.tz - from.tz) * t;
      this.rx = angle(from.rx, to.rx, t);
      this.ry = angle(from.ry, to.ry, t);
      this.rz = angle(from.rz, to.rz, t);
      this.ra = angle(from.ra, to.ra, t);
      return this;
   }

   private static float angle(float from, float to, float t) {
      return from + wrap(to - from) * t;
   }

   static float wrap(float degrees) {
      float a = degrees % 360.0F;
      if (a > 180.0F) {
         a -= 360.0F;
      } else if (a <= -180.0F) {
         a += 360.0F;
      }

      return a;
   }
}
