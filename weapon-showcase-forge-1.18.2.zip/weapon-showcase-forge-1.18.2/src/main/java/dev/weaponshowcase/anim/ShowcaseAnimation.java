package dev.weaponshowcase.anim;

/**
 * The built-in showcase animations. Coordinates are camera space: +x right, +y up, +z towards the player.
 * Rotations: rx tilts the top of the item towards (+) or away from (-) the player, ry turns it around the
 * vertical axis, rz rolls it like a clock hand. Keyframes are {time, tx, ty, tz, rx, ry, rz}.
 * Animations with full turns do not scale their rotation with the intensity option (it would break the loop).
 */
public enum ShowcaseAnimation {
   SHOWCASE("showcase", 2.6F, true, new double[][]{
      {0.00, 0.00, 0.00, 0.00, 0, 0, 0},
      {0.18, -0.30, 0.12, 0.10, -10, 0, 0},
      {0.42, -0.30, 0.12, 0.10, -15, -55, 12},
      {0.68, -0.30, 0.12, 0.10, -15, 50, -12},
      {0.85, -0.30, 0.12, 0.10, -10, 0, 0},
      {1.00, 0.00, 0.00, 0.00, 0, 0, 0}
   }),
   SPIN("spin", 1.9F, false, new double[][]{
      {0.00, 0.00, 0.00, 0.00, 0, 0, 0},
      {0.20, -0.22, 0.10, 0.05, 0, 0, 0},
      {0.80, -0.22, 0.10, 0.05, 0, -360, 0},
      {1.00, 0.00, 0.00, 0.00, 0, -360, 0}
   }),
   FLIP("flip", 1.7F, false, new double[][]{
      {0.00, 0.00, 0.00, 0.00, 0, 0, 0},
      {0.30, -0.05, 0.22, 0.04, -90, 0, 0},
      {0.55, -0.05, 0.26, 0.04, -220, 0, 0},
      {0.80, -0.02, 0.06, 0.02, -360, 0, 0},
      {1.00, 0.00, 0.00, 0.00, -360, 0, 0}
   }),
   TOSS("toss", 2.0F, false, new double[][]{
      {0.00, 0.00, 0.00, 0.00, 0, 0, 0},
      {0.18, -0.05, -0.04, 0.02, 12, 0, 0},
      {0.45, -0.08, 0.34, 0.06, -10, 0, 360},
      {0.70, -0.06, 0.16, 0.04, -5, 0, 720},
      {0.85, -0.02, -0.02, 0.00, 6, 0, 720},
      {1.00, 0.00, 0.00, 0.00, 0, 0, 720}
   }),
   FLOURISH("flourish", 2.2F, true, new double[][]{
      {0.00, 0.00, 0.00, 0.00, 0, 0, 0},
      {0.15, -0.14, 0.05, 0.04, -8, -10, 20},
      {0.35, -0.14, 0.05, 0.04, -8, 18, -40},
      {0.55, -0.14, 0.05, 0.04, -8, -14, 38},
      {0.75, -0.14, 0.05, 0.04, -8, 8, -22},
      {0.90, -0.08, 0.02, 0.02, -4, 0, 8},
      {1.00, 0.00, 0.00, 0.00, 0, 0, 0}
   }),
   EXAMINE("examine", 2.3F, true, new double[][]{
      {0.00, 0.00, 0.00, 0.00, 0, 0, 0},
      {0.25, -0.42, 0.18, 0.26, -32, 26, 8},
      {0.50, -0.42, 0.18, 0.26, -36, 34, -10},
      {0.75, -0.42, 0.18, 0.26, -28, 18, 4},
      {1.00, 0.00, 0.00, 0.00, 0, 0, 0}
   });

   private final String id;
   private final float seconds;
   private final boolean scalesRotation;
   private final Track track;

   ShowcaseAnimation(String id, float seconds, boolean scalesRotation, double[][] keyframes) {
      this.id = id;
      this.seconds = seconds;
      this.scalesRotation = scalesRotation;
      this.track = new Track(keyframes);
   }

   public String id() {
      return this.id;
   }

   public float seconds() {
      return this.seconds;
   }

   public boolean scalesRotation() {
      return this.scalesRotation;
   }

   public Pose evaluate(double t, float intensity, Pose out) {
      this.track.evaluate(t, out);
      return out.scale(intensity, this.scalesRotation ? intensity : 1.0F);
   }

   public ShowcaseAnimation next() {
      ShowcaseAnimation[] all = values();
      return all[(this.ordinal() + 1) % all.length];
   }

   public String translationKey() {
      return "weaponshowcase.animation." + this.id;
   }

   public static ShowcaseAnimation byName(String name) {
      for (ShowcaseAnimation animation : values()) {
         if (animation.name().equalsIgnoreCase(name)) {
            return animation;
         }
      }

      return SHOWCASE;
   }
}
