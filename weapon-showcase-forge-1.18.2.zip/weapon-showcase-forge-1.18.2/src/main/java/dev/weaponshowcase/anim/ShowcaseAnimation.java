package dev.weaponshowcase.anim;

/**
 * The built-in inspect animations. Each one is a seamless loop, in camera space: +x right, +y up, +z towards the
 * player. rx tilts the top of the item towards (+) or away from (-) the player, ry turns it around the vertical axis,
 * rz rolls it like a clock hand and ra spins it around its own length. Keyframes: {time, tx, ty, tz, rx, ry, rz, ra}.
 *
 * Animations with whole turns do not scale their rotation with the intensity option, which would break the loop.
 * A little layered sway (never in step with the loop) keeps repeated cycles from looking mechanical.
 */
public enum ShowcaseAnimation {
   TWIRL("twirl", 2.8F, false, new double[][]{
      {0.00, -0.18, 0.10, 0.10, -8, 0, 0, 0},
      {0.18, -0.20, 0.13, 0.12, -10, -6, 8, 40},
      {0.38, -0.20, 0.09, 0.12, -8, -10, 12, 150},
      {0.55, -0.18, 0.11, 0.11, -10, -4, 6, 200},
      {0.78, -0.18, 0.13, 0.10, -8, -8, 10, 305},
      {1.00, -0.18, 0.10, 0.10, -8, 0, 0, 360}
   }),
   SHOWCASE("showcase", 4.2F, true, new double[][]{
      {0.00, -0.26, 0.12, 0.14, -12, 0, 0, 0},
      {0.20, -0.30, 0.14, 0.18, -16, -52, 14, 0},
      {0.38, -0.30, 0.13, 0.17, -22, -34, 6, 0},
      {0.56, -0.28, 0.12, 0.15, -14, 18, -10, 0},
      {0.78, -0.30, 0.14, 0.18, -16, 54, -16, 0},
      {0.92, -0.28, 0.12, 0.15, -12, 22, -6, 0},
      {1.00, -0.26, 0.12, 0.14, -12, 0, 0, 0}
   }),
   TOSS("toss", 2.6F, false, new double[][]{
      {0.00, -0.12, 0.02, 0.06, -6, 0, 0, 0},
      {0.12, -0.12, -0.03, 0.07, 10, 0, 0, 0},
      {0.30, -0.14, 0.30, 0.08, -90, 0, 4, 0},
      {0.46, -0.14, 0.36, 0.06, -210, 0, -4, 0},
      {0.62, -0.12, 0.20, 0.06, -320, 0, 0, 0},
      {0.74, -0.12, 0.00, 0.07, -366, 0, 0, 0},
      {0.86, -0.12, 0.01, 0.06, -358, 0, 0, 0},
      {1.00, -0.12, 0.02, 0.06, -366, 0, 0, 0}
   }),
   BACKFLIP("backflip", 2.4F, false, new double[][]{
      {0.00, -0.14, 0.06, 0.04, -4, 0, 0, 0},
      {0.25, -0.14, 0.20, -0.06, 100, 0, -6, 0},
      {0.50, -0.14, 0.26, -0.08, 200, 0, 0, 0},
      {0.75, -0.14, 0.12, -0.04, 300, 0, 6, 0},
      {0.90, -0.14, 0.04, 0.04, 352, 0, 0, 0},
      {1.00, -0.14, 0.06, 0.04, 356, 0, 0, 0}
   }),
   FAN("fan", 2.0F, true, new double[][]{
      {0.00, -0.14, 0.06, 0.08, -6, 0, 0, 0},
      {0.14, -0.15, 0.08, 0.09, -8, -10, 48, 0},
      {0.30, -0.15, 0.06, 0.09, -6, 8, -42, 0},
      {0.44, -0.15, 0.08, 0.09, -8, -8, 34, 0},
      {0.60, -0.14, 0.06, 0.08, -6, 6, -24, 0},
      {0.78, -0.14, 0.07, 0.08, -6, -3, 10, 0},
      {1.00, -0.14, 0.06, 0.08, -6, 0, 0, 0}
   }),
   EXAMINE("examine", 5.0F, true, new double[][]{
      {0.00, -0.30, 0.10, 0.14, -14, 0, 0, 0},
      {0.18, -0.42, 0.17, 0.28, -34, 28, 9, 0},
      {0.42, -0.44, 0.18, 0.30, -40, 36, -8, 0},
      {0.64, -0.42, 0.17, 0.28, -30, 12, 6, 0},
      {0.82, -0.40, 0.15, 0.24, -26, -14, 10, 0},
      {1.00, -0.30, 0.10, 0.14, -14, 0, 0, 0}
   }),
   HELICOPTER("helicopter", 2.6F, false, new double[][]{
      {0.00, -0.18, 0.10, 0.08, -10, 0, 6, 0},
      {0.20, -0.20, 0.14, 0.10, -14, -60, 10, 0},
      {0.40, -0.20, 0.12, 0.10, -12, -170, 4, 0},
      {0.60, -0.20, 0.14, 0.10, -14, -240, 8, 0},
      {0.80, -0.19, 0.12, 0.09, -12, -320, 6, 0},
      {1.00, -0.18, 0.10, 0.08, -10, -360, 6, 0}
   }),
   SWAY("sway", 3.8F, true, new double[][]{
      {0.00, -0.20, 0.10, 0.12, -10, 0, 0, 0},
      {0.18, -0.22, 0.12, 0.14, -14, -8, 6, 95},
      {0.34, -0.22, 0.11, 0.14, -12, -6, 4, 80},
      {0.52, -0.20, 0.10, 0.12, -10, 0, 0, 0},
      {0.70, -0.22, 0.12, 0.14, -14, 8, -6, -95},
      {0.86, -0.22, 0.11, 0.14, -12, 6, -4, -80},
      {1.00, -0.20, 0.10, 0.12, -10, 0, 0, 0}
   });

   private final String id;
   private final float seconds;
   private final boolean scalesRotation;
   private final Track track;

   ShowcaseAnimation(String id, float seconds, boolean scalesRotation, double[][] keyframes) {
      this.id = id;
      this.seconds = seconds;
      this.scalesRotation = scalesRotation;
      this.track = new Track(keyframes);
   }

   public String id() {
      return this.id;
   }

   /** Length of one loop, in seconds, at normal speed. */
   public float seconds() {
      return this.seconds;
   }

   /**
    * Pose after {@code animSeconds} of animation time (real time multiplied by the speed option). Loops forever; the
    * caller decides when to stop. The layered sway runs on {@code realSeconds} so a high speed does not make it jitter.
    */
   public Pose evaluate(double animSeconds, double realSeconds, float intensity, Pose out) {
      this.track.evaluate(animSeconds / (double)this.seconds, out);
      out.scale(intensity, this.scalesRotation ? intensity : 1.0F);
      double t = realSeconds;
      out.tx += (float)(0.006 * Math.sin(t * 1.3) + 0.004 * Math.sin(t * 2.9 + 1.0));
      out.ty += (float)(0.008 * Math.sin(t * 1.1 + 0.5) + 0.004 * Math.sin(t * 2.3));
      out.tz += (float)(0.005 * Math.sin(t * 0.8 + 2.0));
      out.rx += (float)(1.0 * Math.sin(t * 0.9 + 2.0) + 0.6 * Math.sin(t * 2.1));
      out.rz += (float)(1.2 * Math.sin(t * 1.7) + 0.8 * Math.sin(t * 3.1 + 0.7));
      return out;
   }

   public ShowcaseAnimation next() {
      ShowcaseAnimation[] all = values();
      return all[(this.ordinal() + 1) % all.length];
   }

   public String translationKey() {
      return "weaponshowcase.animation." + this.id;
   }

   public static ShowcaseAnimation byName(String name) {
      for (ShowcaseAnimation animation : values()) {
         if (animation.name().equalsIgnoreCase(name)) {
            return animation;
         }
      }

      return SHOWCASE;
   }
}
