package dev.weaponshowcase;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Vector3f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.client.event.RenderHandEvent;

/**
 * Vanilla only draws the first-person arm when the hand is empty (or holds a map). This draws it next to a held item
 * too (in either hand), using the same placement maths as vanilla's empty-hand arm, so it follows the swing and the inspect animation.
 * It is drawn just before vanilla draws the item.
 */
final class ArmRenderer {
   private ArmRenderer() {
   }

   static void draw(RenderHandEvent event, LocalPlayer player) {
      ItemStack stack = event.getItemStack();
      InteractionHand hand = event.getHand();
      if (!ShowcaseConfig.get().showArm()
         || stack.isEmpty()
         || player.isInvisible()
         || player.isUsingItem() && player.getUsedItemHand() == hand
         || player.isAutoSpinAttack()
         || stack.is(Items.FILLED_MAP)
         || stack.is(Items.CROSSBOW)) {
         return;
      }

      EntityRenderer<?> renderer = Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(player);
      if (!(renderer instanceof PlayerRenderer playerRenderer)) {
         return;
      }

      HumanoidArm arm = hand == InteractionHand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
      boolean right = arm != HumanoidArm.LEFT;
      float f = right ? 1.0F : -1.0F;
      float swing = event.getSwingProgress();
      float equip = event.getEquipProgress();
      PoseStack poseStack = event.getPoseStack();

      poseStack.pushPose();
      float root = Mth.sqrt(swing);
      float sideSwing = -0.3F * Mth.sin(root * (float)Math.PI);
      float liftSwing = 0.4F * Mth.sin(root * ((float)Math.PI * 2.0F));
      float pushSwing = -0.4F * Mth.sin(swing * (float)Math.PI);
      poseStack.translate(
         (double)(f * (sideSwing + 0.64000005F)),
         (double)(liftSwing + -0.6F + equip * -0.6F),
         (double)(pushSwing + -0.71999997F)
      );
      poseStack.mulPose(Vector3f.YP.rotationDegrees(f * 45.0F));
      float curve = Mth.sin(swing * swing * (float)Math.PI);
      float arc = Mth.sin(root * (float)Math.PI);
      poseStack.mulPose(Vector3f.YP.rotationDegrees(f * arc * 70.0F));
      poseStack.mulPose(Vector3f.ZP.rotationDegrees(f * curve * -20.0F));
      poseStack.translate((double)(f * -1.0F), 3.6F, 3.5);
      poseStack.mulPose(Vector3f.ZP.rotationDegrees(f * 120.0F));
      poseStack.mulPose(Vector3f.XP.rotationDegrees(200.0F));
      poseStack.mulPose(Vector3f.YP.rotationDegrees(f * -135.0F));
      poseStack.translate((double)(f * 5.6F), 0.0, 0.0);
      if (right) {
         playerRenderer.renderRightHand(poseStack, event.getMultiBufferSource(), event.getPackedLight(), player);
      } else {
         playerRenderer.renderLeftHand(poseStack, event.getMultiBufferSource(), event.getPackedLight(), player);
      }

      poseStack.popPose();
   }
}
