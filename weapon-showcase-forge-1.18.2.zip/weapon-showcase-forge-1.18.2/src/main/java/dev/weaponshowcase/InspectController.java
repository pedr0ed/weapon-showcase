package dev.weaponshowcase;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Matrix3f;
import com.mojang.math.Matrix4f;
import com.mojang.math.Vector3f;
import dev.weaponshowcase.anim.Pose;
import dev.weaponshowcase.anim.ShowcaseAnimation;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TridentItem;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.common.ToolActions;

/**
 * Plays the showcase animation by offsetting the first-person hand before vanilla draws it. The offset is applied
 * to the PoseStack from RenderHandEvent (main hand) and undone when the off-hand event arrives, so the off hand is
 * never affected.
 */
public final class InspectController {
   private static final int BLEND_OUT_TICKS = 5;
   private static final Random RANDOM = new Random();
   private static final Pose POSE = new Pose();

   private static long ticks;
   private static boolean active;
   private static ShowcaseAnimation current = ShowcaseAnimation.SHOWCASE;
   private static ShowcaseAnimation last;
   private static long startTick;
   private static float durationTicks = 40.0F;
   private static long cancelTick = -1L;
   private static float frozenProgress;
   private static int startSlot;
   private static ItemStack startStack = ItemStack.EMPTY;

   private static Matrix4f savedPose;
   private static Matrix3f savedNormal;
   private static boolean restorePending;

   private InspectController() {
   }

   public static boolean isActive() {
      return active;
   }

   public static void tick(Minecraft minecraft) {
      ticks++;
      if (!active) {
         return;
      }

      LocalPlayer player = minecraft.player;
      if (player == null || minecraft.level == null) {
         stop();
      } else if (cancelTick >= 0L) {
         if (ticks - cancelTick >= BLEND_OUT_TICKS) {
            stop();
         }
      } else if (shouldCancel(minecraft, player)) {
         frozenProgress = progress(0.0F);
         cancelTick = ticks;
      } else if ((float)(ticks - startTick) >= durationTicks) {
         stop();
      }
   }

   private static boolean shouldCancel(Minecraft minecraft, LocalPlayer player) {
      ShowcaseConfig config = ShowcaseConfig.get();
      return minecraft.screen != null
         || !minecraft.options.getCameraType().isFirstPerson()
         || player.isUsingItem()
         || player.getInventory().selected != startSlot
         || !ItemStack.isSame(player.getMainHandItem(), startStack)
         || config.cancelOnSwing() && player.swinging;
   }

   /** Starts the animation if allowed. With {@code force}, the tools-only filter is ignored (used by the preview). */
   public static boolean start(Minecraft minecraft, boolean force) {
      LocalPlayer player = minecraft.player;
      if (player == null || minecraft.level == null || active || minecraft.screen != null) {
         return false;
      }

      if (!minecraft.options.getCameraType().isFirstPerson() || player.isUsingItem() || player.swinging) {
         return false;
      }

      ShowcaseConfig config = ShowcaseConfig.get();
      ItemStack stack = player.getMainHandItem();
      if (!force) {
         if (stack.isEmpty() && !config.allowEmptyHand()) {
            return false;
         }

         if (!stack.isEmpty() && config.toolsOnly() && !isToolOrWeapon(stack)) {
            return false;
         }
      }

      current = pick(config);
      last = current;
      durationTicks = Math.max(8.0F, current.seconds() * 20.0F / config.speed());
      startTick = ticks;
      cancelTick = -1L;
      startSlot = player.getInventory().selected;
      startStack = stack.copy();
      active = true;
      return true;
   }

   private static ShowcaseAnimation pick(ShowcaseConfig config) {
      if (!config.randomAnimation()) {
         return config.animation();
      }

      ShowcaseAnimation[] all = ShowcaseAnimation.values();
      ShowcaseAnimation choice = all[RANDOM.nextInt(all.length)];
      if (choice == last) {
         choice = choice.next();
      }

      return choice;
   }

   public static void stop() {
      active = false;
      cancelTick = -1L;
      startStack = ItemStack.EMPTY;
   }

   private static boolean isToolOrWeapon(ItemStack stack) {
      return stack.getItem() instanceof DiggerItem
         || stack.getItem() instanceof SwordItem
         || stack.getItem() instanceof TridentItem
         || stack.getItem() instanceof ProjectileWeaponItem
         || stack.getItem() instanceof ShieldItem
         || stack.canPerformAction(ToolActions.SWORD_SWEEP)
         || stack.canPerformAction(ToolActions.AXE_DIG)
         || stack.canPerformAction(ToolActions.PICKAXE_DIG)
         || stack.canPerformAction(ToolActions.SHOVEL_DIG)
         || stack.canPerformAction(ToolActions.HOE_DIG);
   }

   private static float progress(float partialTick) {
      float elapsed = (float)(ticks - startTick) + partialTick;
      return Math.max(0.0F, Math.min(1.0F, elapsed / durationTicks));
   }

   public static void onRenderHand(RenderHandEvent event) {
      PoseStack poseStack = event.getPoseStack();
      if (event.getHand() == InteractionHand.OFF_HAND) {
         restore(poseStack);
         return;
      }

      restorePending = false;
      Minecraft minecraft = Minecraft.getInstance();
      LocalPlayer player = minecraft.player;
      if (!active || player == null) {
         return;
      }

      float partial = event.getPartialTicks();
      float blend = 1.0F;
      float progress;
      if (cancelTick >= 0L) {
         progress = frozenProgress;
         float into = (float)(ticks - cancelTick) + partial;
         blend = Math.max(0.0F, 1.0F - into / (float)BLEND_OUT_TICKS);
         blend *= blend;
      } else {
         progress = progress(partial);
      }

      ShowcaseConfig config = ShowcaseConfig.get();
      current.evaluate((double)progress, config.intensity(), POSE);
      POSE.fade(blend);
      float side = player.getMainArm() == net.minecraft.world.entity.HumanoidArm.RIGHT ? 1.0F : -1.0F;

      savedPose = poseStack.last().pose().copy();
      savedNormal = poseStack.last().normal().copy();
      restorePending = true;

      // Pivot roughly where the hand holds the item, in camera space.
      float px = 0.5F * side;
      float py = -0.35F;
      float pz = -0.75F;
      poseStack.translate((double)(POSE.tx * side), (double)POSE.ty, (double)POSE.tz);
      poseStack.translate((double)px, (double)py, (double)pz);
      poseStack.mulPose(Vector3f.ZP.rotationDegrees(POSE.rz * side));
      poseStack.mulPose(Vector3f.YP.rotationDegrees(POSE.ry * side));
      poseStack.mulPose(Vector3f.XP.rotationDegrees(POSE.rx));
      poseStack.translate((double)(-px), (double)(-py), (double)(-pz));
   }

   private static void restore(PoseStack poseStack) {
      if (restorePending && savedPose != null && savedNormal != null) {
         poseStack.last().pose().load(savedPose);
         poseStack.last().normal().load(savedNormal);
      }

      restorePending = false;
   }
}
