package dev.weaponshowcase;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Matrix3f;
import com.mojang.math.Matrix4f;
import com.mojang.math.Vector3f;
import dev.weaponshowcase.anim.Pose;
import dev.weaponshowcase.anim.ShowcaseAnimation;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TridentItem;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.common.ToolActions;

/**
 * Plays the inspect animation by offsetting the first-person hand before vanilla draws it. The offset is applied to
 * the PoseStack from RenderHandEvent (main hand) and undone when the off-hand event arrives, so the off hand is
 * never affected.
 *
 * The animation loops until the player does something else. Pressing the key again restarts it with a different
 * animation, blending from wherever the hand currently is. Starting and stopping also blend, so nothing snaps.
 */
public final class InspectController {
   private static final float BLEND_IN_TICKS = 8.0F;
   private static final float BLEND_SWITCH_TICKS = 10.0F;
   private static final float BLEND_OUT_TICKS = 6.0F;
   private static final Random RANDOM = new Random();

   private static final Pose ZERO = new Pose();
   private static final Pose TARGET = new Pose();
   private static final Pose FROM = new Pose();
   private static final Pose SHOWN = new Pose();

   private static long ticks;
   private static boolean active;
   private static boolean ending;
   private static ShowcaseAnimation current = ShowcaseAnimation.SHOWCASE;
   private static long startTick;
   private static long blendStartTick;
   private static float blendTicks = BLEND_IN_TICKS;
   private static int startSlot;
   private static ItemStack startStack = ItemStack.EMPTY;

   private static Matrix4f savedPose;
   private static Matrix3f savedNormal;
   private static boolean restorePending;

   private InspectController() {
   }

   public static boolean isActive() {
      return active;
   }

   public static void tick(Minecraft minecraft) {
      ticks++;
      if (!active) {
         return;
      }

      LocalPlayer player = minecraft.player;
      if (player == null || minecraft.level == null) {
         stop();
      } else if (ending) {
         if ((float)(ticks - blendStartTick) >= BLEND_OUT_TICKS) {
            stop();
         }
      } else if (shouldCancel(minecraft, player)) {
         beginEnding();
      } else if (!ShowcaseConfig.get().loop() && elapsedSeconds(0.0F) >= (double)current.seconds()) {
         beginEnding();
      }
   }

   private static boolean shouldCancel(Minecraft minecraft, LocalPlayer player) {
      ShowcaseConfig config = ShowcaseConfig.get();
      return minecraft.screen != null
         || !minecraft.options.getCameraType().isFirstPerson()
         || player.isUsingItem()
         || player.getInventory().selected != startSlot
         || !ItemStack.isSame(player.getMainHandItem(), startStack)
         || config.cancelOnSwing() && player.swinging;
   }

   /** Called when the inspect key is pressed: starts the animation, or restarts it with a different one. */
   public static boolean press(Minecraft minecraft, boolean force) {
      LocalPlayer player = minecraft.player;
      if (player == null || minecraft.level == null || minecraft.screen != null) {
         return false;
      }

      if (!minecraft.options.getCameraType().isFirstPerson() || player.isUsingItem() || player.swinging) {
         return false;
      }

      ShowcaseConfig config = ShowcaseConfig.get();
      ItemStack stack = player.getMainHandItem();
      if (active) {
         // Restart on top of what is playing, with another animation, blending from the current pose.
         FROM.set(SHOWN);
         current = another(config);
         startTick = ticks;
         blendStartTick = ticks;
         blendTicks = BLEND_SWITCH_TICKS;
         ending = false;
         startSlot = player.getInventory().selected;
         startStack = stack.copy();
         return true;
      }

      if (!force) {
         if (stack.isEmpty() && !config.allowEmptyHand()) {
            return false;
         }

         if (!stack.isEmpty() && config.toolsOnly() && !isToolOrWeapon(stack)) {
            return false;
         }
      }

      current = config.randomAnimation() ? randomOther(null) : config.animation();
      FROM.clear();
      SHOWN.clear();
      startTick = ticks;
      blendStartTick = ticks;
      blendTicks = BLEND_IN_TICKS;
      ending = false;
      startSlot = player.getInventory().selected;
      startStack = stack.copy();
      active = true;
      return true;
   }

   /** Fades the animation out (used by Shift + the inspect key). */
   public static void requestStop() {
      if (active && !ending) {
         beginEnding();
      }
   }

   private static void beginEnding() {
      FROM.set(SHOWN);
      blendStartTick = ticks;
      blendTicks = BLEND_OUT_TICKS;
      ending = true;
   }

   private static ShowcaseAnimation another(ShowcaseConfig config) {
      return config.randomAnimation() ? randomOther(current) : current.next();
   }

   private static ShowcaseAnimation randomOther(ShowcaseAnimation avoid) {
      ShowcaseAnimation[] all = ShowcaseAnimation.values();
      ShowcaseAnimation choice = all[RANDOM.nextInt(all.length)];
      if (choice == avoid) {
         choice = choice.next();
      }

      return choice;
   }

   public static void stop() {
      active = false;
      ending = false;
      startStack = ItemStack.EMPTY;
   }

   private static boolean isToolOrWeapon(ItemStack stack) {
      return stack.getItem() instanceof DiggerItem
         || stack.getItem() instanceof SwordItem
         || stack.getItem() instanceof TridentItem
         || stack.getItem() instanceof ProjectileWeaponItem
         || stack.getItem() instanceof ShieldItem
         || stack.canPerformAction(ToolActions.SWORD_SWEEP)
         || stack.canPerformAction(ToolActions.AXE_DIG)
         || stack.canPerformAction(ToolActions.PICKAXE_DIG)
         || stack.canPerformAction(ToolActions.SHOVEL_DIG)
         || stack.canPerformAction(ToolActions.HOE_DIG);
   }

   /** Seconds the current animation has been playing, with the speed option applied. */
   private static double elapsedSeconds(float partialTick) {
      float speed = ShowcaseConfig.get().speed();
      return (double)(((float)(ticks - startTick) + partialTick) / 20.0F * speed);
   }

   public static void onRenderHand(RenderHandEvent event) {
      PoseStack poseStack = event.getPoseStack();
      if (event.getHand() == InteractionHand.OFF_HAND) {
         restore(poseStack);
         return;
      }

      restorePending = false;
      Minecraft minecraft = Minecraft.getInstance();
      LocalPlayer player = minecraft.player;
      if (player == null) {
         return;
      }

      if (active) {
         applyInspect(poseStack, player, event.getPartialTicks());
      }

      ArmRenderer.draw(event, player);
   }

   private static void applyInspect(PoseStack poseStack, LocalPlayer player, float partial) {
      ShowcaseConfig config = ShowcaseConfig.get();
      if (ending) {
         TARGET.clear();
      } else {
         current.evaluate(elapsedSeconds(partial), config.intensity(), TARGET);
      }

      TARGET.normalize();
      float blend = Math.max(0.0F, Math.min(1.0F, ((float)(ticks - blendStartTick) + partial) / blendTicks));
      blend = blend * blend * (3.0F - 2.0F * blend);
      SHOWN.blend(FROM, TARGET, blend).normalize();

      float side = player.getMainArm() == HumanoidArm.RIGHT ? 1.0F : -1.0F;
      savedPose = poseStack.last().pose().copy();
      savedNormal = poseStack.last().normal().copy();
      restorePending = true;

      // Pivot roughly where the hand holds the item, in camera space; the item's long axis points up and inwards.
      float px = 0.5F * side;
      float py = -0.35F;
      float pz = -0.75F;
      Vector3f axis = new Vector3f(-0.35F * side, 0.9F, -0.25F);
      axis.normalize();
      poseStack.translate((double)(SHOWN.tx * side), (double)SHOWN.ty, (double)SHOWN.tz);
      poseStack.translate((double)px, (double)py, (double)pz);
      poseStack.mulPose(Vector3f.ZP.rotationDegrees(SHOWN.rz * side));
      poseStack.mulPose(Vector3f.YP.rotationDegrees(SHOWN.ry * side));
      poseStack.mulPose(Vector3f.XP.rotationDegrees(SHOWN.rx));
      poseStack.mulPose(axis.rotationDegrees(SHOWN.ra * side));
      poseStack.translate((double)(-px), (double)(-py), (double)(-pz));
   }

   private static void restore(PoseStack poseStack) {
      if (restorePending && savedPose != null && savedNormal != null) {
         poseStack.last().pose().load(savedPose);
         poseStack.last().normal().load(savedNormal);
      }

      restorePending = false;
   }
}
