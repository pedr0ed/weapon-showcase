package dev.weaponshowcase.screen;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.weaponshowcase.InspectController;
import dev.weaponshowcase.ShowcaseConfig;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;

/** Settings screen: animation, speed, intensity and behaviour toggles, plus a preview button. */
public final class ConfigScreen extends Screen {
   private final Screen parent;

   public ConfigScreen(Screen parent) {
      super(new TranslatableComponent("weaponshowcase.screen.title"));
      this.parent = parent;
   }

   @Override
   protected void init() {
      ShowcaseConfig config = ShowcaseConfig.get();
      int columnWidth = 150;
      int gap = 10;
      int left = this.width / 2 - columnWidth - gap / 2;
      int right = this.width / 2 + gap / 2;
      int y = 36;
      int step = 21;

      this.addRenderableWidget(new Button(left, y, columnWidth, 20, animationLabel(config), button -> {
         config.setAnimation(config.animation().next());
         button.setMessage(animationLabel(config));
      }));
      this.addRenderableWidget(toggle(right, y, columnWidth, "weaponshowcase.screen.random", config::randomAnimation, config::setRandomAnimation));
      y += step;

      this.addRenderableWidget(new ValueSlider(
         left, y, columnWidth, 20, 0.5, 2.0, 0.05, config.speed(),
         value -> new TranslatableComponent("weaponshowcase.screen.speed", String.format("%.2f", value)),
         value -> config.setSpeed(value.floatValue())
      ));
      this.addRenderableWidget(new ValueSlider(
         right, y, columnWidth, 20, 0.5, 1.5, 0.05, config.intensity(),
         value -> new TranslatableComponent("weaponshowcase.screen.intensity", String.format("%.2f", value)),
         value -> config.setIntensity(value.floatValue())
      ));
      y += step;

      this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.loop", config::loop, config::setLoop));
      this.addRenderableWidget(toggle(right, y, columnWidth, "weaponshowcase.screen.show_arm", config::showArm, config::setShowArm));
      y += step;

      this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.tools_only", config::toolsOnly, config::setToolsOnly));
      this.addRenderableWidget(toggle(right, y, columnWidth, "weaponshowcase.screen.cancel_on_swing", config::cancelOnSwing, config::setCancelOnSwing));
      y += step;

      this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.empty_hand", config::allowEmptyHand, config::setAllowEmptyHand));
      y += step;

      this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.hand_fov_toggle", config::handFovEnabled, config::setHandFovEnabled));
      this.addRenderableWidget(new ValueSlider(
         right, y, columnWidth, 20, 30.0, 110.0, 1.0, config.handFov(),
         value -> new TranslatableComponent("weaponshowcase.screen.hand_fov", String.format("%.0f", value)),
         value -> config.setHandFov(value.floatValue())
      ));
      y += step;

      this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.world_fov_toggle", config::worldFovEnabled, config::setWorldFovEnabled));
      this.addRenderableWidget(new ValueSlider(
         right, y, columnWidth, 20, 30.0, 160.0, 1.0, config.worldFov(),
         value -> new TranslatableComponent("weaponshowcase.screen.world_fov", String.format("%.0f", value)),
         value -> config.setWorldFov(value.floatValue())
      ));

      int bottom = this.height - 28;
      this.addRenderableWidget(new Button(left, bottom, columnWidth, 20, new TranslatableComponent("weaponshowcase.screen.preview"), button -> {
         ShowcaseConfig.save();
         this.minecraft.setScreen(null);
         InspectController.press(this.minecraft, true);
      }));
      this.addRenderableWidget(new Button(right, bottom, columnWidth, 20, new TranslatableComponent("weaponshowcase.screen.done"), button -> this.onClose()));
   }

   private static Component animationLabel(ShowcaseConfig config) {
      return new TranslatableComponent("weaponshowcase.screen.animation", new TranslatableComponent(config.animation().translationKey()));
   }

   private static Button toggle(int x, int y, int width, String key, BooleanSupplier getter, Consumer<Boolean> setter) {
      return new Button(x, y, width, 20, toggleLabel(key, getter.getAsBoolean()), button -> {
         boolean value = !getter.getAsBoolean();
         setter.accept(value);
         button.setMessage(toggleLabel(key, value));
      });
   }

   private static Component toggleLabel(String key, boolean value) {
      return new TranslatableComponent(key, new TranslatableComponent(value ? "weaponshowcase.screen.on" : "weaponshowcase.screen.off"));
   }

   @Override
   public void render(PoseStack poseStack, int mouseX, int mouseY, float partialTick) {
      this.renderBackground(poseStack);
      drawCenteredString(poseStack, this.font, this.title, this.width / 2, 8, 0xFFFFFF);
      super.render(poseStack, mouseX, mouseY, partialTick);
      drawCenteredString(poseStack, this.font, new TranslatableComponent("weaponshowcase.screen.hint"), this.width / 2, 21, 0xA0A0A0);
   }

   @Override
   public void removed() {
      ShowcaseConfig.save();
   }

   @Override
   public void onClose() {
      ShowcaseConfig.save();
      this.minecraft.setScreen(this.parent);
   }
}
