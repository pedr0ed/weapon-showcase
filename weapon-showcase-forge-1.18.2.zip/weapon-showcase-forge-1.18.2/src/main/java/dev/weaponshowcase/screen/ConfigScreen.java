package dev.weaponshowcase.screen;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.weaponshowcase.InspectController;
import dev.weaponshowcase.ShowcaseConfig;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;

/**
 * Settings screen in two pages: the animation options, and the hand position / field of view options.
 * Changing page opens a fresh screen, which keeps the widget code simple.
 */
public final class ConfigScreen extends Screen {
   private static final int PAGE_ANIMATION = 0;
   private static final int PAGE_VIEW = 1;
   private final Screen parent;
   private final int page;

   public ConfigScreen(Screen parent) {
      this(parent, PAGE_ANIMATION);
   }

   private ConfigScreen(Screen parent, int page) {
      super(new TranslatableComponent("weaponshowcase.screen.title"));
      this.parent = parent;
      this.page = page;
   }

   @Override
   protected void init() {
      ShowcaseConfig config = ShowcaseConfig.get();
      int columnWidth = 150;
      int gap = 10;
      int left = this.width / 2 - columnWidth - gap / 2;
      int right = this.width / 2 + gap / 2;
      int y = 40;
      int step = 24;

      if (this.page == PAGE_ANIMATION) {
         this.addRenderableWidget(new Button(left, y, columnWidth, 20, animationLabel(config), button -> {
            config.setAnimation(config.animation().next());
            button.setMessage(animationLabel(config));
         }));
         this.addRenderableWidget(toggle(right, y, columnWidth, "weaponshowcase.screen.random", config::randomAnimation, config::setRandomAnimation));
         y += step;

         this.addRenderableWidget(new ValueSlider(
            left, y, columnWidth, 20, 0.5, 10.0, 0.05, true, config.speed(),
            value -> new TranslatableComponent("weaponshowcase.screen.speed", String.format("%.2f", value)),
            value -> config.setSpeed(value.floatValue())
         ));
         this.addRenderableWidget(new ValueSlider(
            right, y, columnWidth, 20, 0.5, 1.5, 0.05, config.intensity(),
            value -> new TranslatableComponent("weaponshowcase.screen.intensity", String.format("%.2f", value)),
            value -> config.setIntensity(value.floatValue())
         ));
         y += step;

         this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.loop", config::loop, config::setLoop));
         this.addRenderableWidget(toggle(right, y, columnWidth, "weaponshowcase.screen.show_arm", config::showArm, config::setShowArm));
         y += step;

         this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.tools_only", config::toolsOnly, config::setToolsOnly));
         this.addRenderableWidget(toggle(right, y, columnWidth, "weaponshowcase.screen.cancel_on_swing", config::cancelOnSwing, config::setCancelOnSwing));
         y += step;

         this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.empty_hand", config::allowEmptyHand, config::setAllowEmptyHand));
      } else {
         this.addRenderableWidget(new ValueSlider(
            left, y, columnWidth, 20, -0.6, 0.6, 0.01, config.handX(),
            value -> new TranslatableComponent("weaponshowcase.screen.hand_x", String.format("%.2f", value)),
            value -> config.setHandX(value.floatValue())
         ));
         this.addRenderableWidget(new ValueSlider(
            right, y, columnWidth, 20, -0.6, 0.6, 0.01, config.handY(),
            value -> new TranslatableComponent("weaponshowcase.screen.hand_y", String.format("%.2f", value)),
            value -> config.setHandY(value.floatValue())
         ));
         y += step;

         this.addRenderableWidget(new ValueSlider(
            left, y, columnWidth, 20, -0.3, 1.0, 0.01, config.handSeparation(),
            value -> new TranslatableComponent("weaponshowcase.screen.hand_separation", String.format("%.2f", value)),
            value -> config.setHandSeparation(value.floatValue())
         ));
         this.addRenderableWidget(new Button(right, y, columnWidth, 20, new TranslatableComponent("weaponshowcase.screen.reset_hands"), button -> {
            config.resetHandPosition();
            this.minecraft.setScreen(new ConfigScreen(this.parent, this.page));
         }));
         y += step;

         this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.hand_fov_toggle", config::handFovEnabled, config::setHandFovEnabled));
         this.addRenderableWidget(new ValueSlider(
            right, y, columnWidth, 20, 30.0, 110.0, 1.0, config.handFov(),
            value -> new TranslatableComponent("weaponshowcase.screen.hand_fov", String.format("%.0f", value)),
            value -> config.setHandFov(value.floatValue())
         ));
         y += step;

         this.addRenderableWidget(toggle(left, y, columnWidth, "weaponshowcase.screen.world_fov_toggle", config::worldFovEnabled, config::setWorldFovEnabled));
         this.addRenderableWidget(new ValueSlider(
            right, y, columnWidth, 20, 30.0, 160.0, 1.0, config.worldFov(),
            value -> new TranslatableComponent("weaponshowcase.screen.world_fov", String.format("%.0f", value)),
            value -> config.setWorldFov(value.floatValue())
         ));
      }

      int buttonWidth = 98;
      int bottom = this.height - 28;
      int startX = this.width / 2 - (buttonWidth * 3 + 10) / 2;
      Component pageLabel = new TranslatableComponent(this.page == PAGE_ANIMATION ? "weaponshowcase.screen.page_view" : "weaponshowcase.screen.page_animation");
      this.addRenderableWidget(new Button(startX, bottom, buttonWidth, 20, pageLabel, button -> {
         ShowcaseConfig.save();
         this.minecraft.setScreen(new ConfigScreen(this.parent, this.page == PAGE_ANIMATION ? PAGE_VIEW : PAGE_ANIMATION));
      }));
      this.addRenderableWidget(new Button(startX + buttonWidth + 5, bottom, buttonWidth, 20, new TranslatableComponent("weaponshowcase.screen.preview"), button -> {
         ShowcaseConfig.save();
         this.minecraft.setScreen(null);
         InspectController.press(this.minecraft, true);
      }));
      this.addRenderableWidget(new Button(startX + (buttonWidth + 5) * 2, bottom, buttonWidth, 20, new TranslatableComponent("weaponshowcase.screen.done"), button -> this.onClose()));
   }

   private static Component animationLabel(ShowcaseConfig config) {
      return new TranslatableComponent("weaponshowcase.screen.animation", new TranslatableComponent(config.animation().translationKey()));
   }

   private static Button toggle(int x, int y, int width, String key, BooleanSupplier getter, Consumer<Boolean> setter) {
      return new Button(x, y, width, 20, toggleLabel(key, getter.getAsBoolean()), button -> {
         boolean value = !getter.getAsBoolean();
         setter.accept(value);
         button.setMessage(toggleLabel(key, value));
      });
   }

   private static Component toggleLabel(String key, boolean value) {
      return new TranslatableComponent(key, new TranslatableComponent(value ? "weaponshowcase.screen.on" : "weaponshowcase.screen.off"));
   }

   @Override
   public void render(PoseStack poseStack, int mouseX, int mouseY, float partialTick) {
      this.renderBackground(poseStack);
      drawCenteredString(poseStack, this.font, this.title, this.width / 2, 10, 0xFFFFFF);
      String hint = this.page == PAGE_ANIMATION ? "weaponshowcase.screen.hint" : "weaponshowcase.screen.hint_view";
      drawCenteredString(poseStack, this.font, new TranslatableComponent(hint), this.width / 2, 24, 0xA0A0A0);
      super.render(poseStack, mouseX, mouseY, partialTick);
   }

   @Override
   public void removed() {
      ShowcaseConfig.save();
   }

   @Override
   public void onClose() {
      ShowcaseConfig.save();
      this.minecraft.setScreen(this.parent);
   }
}
