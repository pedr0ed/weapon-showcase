package dev.weaponshowcase.screen;

import java.util.function.Consumer;
import java.util.function.DoubleFunction;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.util.Mth;

/** A slider that maps its 0..1 position onto a value range, rounded to a fixed step. */
final class ValueSlider extends AbstractSliderButton {
   private final double min;
   private final double max;
   private final double step;
   private final DoubleFunction<Component> label;
   private final Consumer<Double> onChange;

   ValueSlider(int x, int y, int width, int height, double min, double max, double step, double current, DoubleFunction<Component> label, Consumer<Double> onChange) {
      super(x, y, width, height, TextComponent.EMPTY, (current - min) / (max - min));
      this.min = min;
      this.max = max;
      this.step = step;
      this.label = label;
      this.onChange = onChange;
      this.updateMessage();
   }

   private double actual() {
      double raw = this.min + (this.max - this.min) * this.value;
      return Mth.clamp((double)Math.round(raw / this.step) * this.step, this.min, this.max);
   }

   @Override
   protected void updateMessage() {
      this.setMessage(this.label.apply(this.actual()));
   }

   @Override
   protected void applyValue() {
      this.onChange.accept(this.actual());
   }
}
