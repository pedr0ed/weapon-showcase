package dev.weaponshowcase.screen;

import java.util.function.Consumer;
import java.util.function.DoubleFunction;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.util.Mth;

/**
 * A slider that maps its 0..1 position onto a value range, rounded to a fixed step. A logarithmic slider gives fine
 * control at the low end of a wide range (such as the 0.5x to 10x speed).
 */
final class ValueSlider extends AbstractSliderButton {
   private final double min;
   private final double max;
   private final double step;
   private final boolean logarithmic;
   private final DoubleFunction<Component> label;
   private final Consumer<Double> onChange;

   ValueSlider(int x, int y, int width, int height, double min, double max, double step, double current, DoubleFunction<Component> label, Consumer<Double> onChange) {
      this(x, y, width, height, min, max, step, false, current, label, onChange);
   }

   ValueSlider(
      int x, int y, int width, int height, double min, double max, double step, boolean logarithmic, double current,
      DoubleFunction<Component> label, Consumer<Double> onChange
   ) {
      super(x, y, width, height, TextComponent.EMPTY, position(current, min, max, logarithmic));
      this.min = min;
      this.max = max;
      this.step = step;
      this.logarithmic = logarithmic;
      this.label = label;
      this.onChange = onChange;
      this.updateMessage();
   }

   private static double position(double current, double min, double max, boolean logarithmic) {
      double c = Mth.clamp(current, min, max);
      return logarithmic ? Math.log(c / min) / Math.log(max / min) : (c - min) / (max - min);
   }

   private double actual() {
      double raw = this.logarithmic ? this.min * Math.pow(this.max / this.min, this.value) : this.min + (this.max - this.min) * this.value;
      return Mth.clamp((double)Math.round(raw / this.step) * this.step, this.min, this.max);
   }

   @Override
   protected void updateMessage() {
      this.setMessage(this.label.apply(this.actual()));
   }

   @Override
   protected void applyValue() {
      this.onChange.accept(this.actual());
   }
}
