package dev.weaponshowcase;

import dev.weaponshowcase.anim.ShowcaseAnimation;
import dev.weaponshowcase.screen.ConfigScreen;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.client.ConfigGuiHandler;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/** Everything that touches client-only classes lives here, so a server never loads it. */
final class WeaponShowcaseClient {
   private WeaponShowcaseClient() {
   }

   static void init() {
      ShowcaseConfig.get();
      IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

      modBus.addListener((FMLClientSetupEvent event) -> event.enqueueWork(() -> {
         for (KeyMapping key : Keys.all()) {
            ClientRegistry.registerKeyBinding(key);
         }
      }));

      MinecraftForge.EVENT_BUS.addListener((TickEvent.ClientTickEvent event) -> {
         if (event.phase == TickEvent.Phase.END) {
            onTick(Minecraft.getInstance());
         }
      });
      MinecraftForge.EVENT_BUS.addListener(InspectController::onRenderHand);
      MinecraftForge.EVENT_BUS.addListener(FovControl::onRenderTick);
      MinecraftForge.EVENT_BUS.addListener(FovControl::onRenderLevelLast);
      MinecraftForge.EVENT_BUS.addListener(FovControl::onFieldOfView);

      ModLoadingContext.get().registerExtensionPoint(
         ConfigGuiHandler.ConfigGuiFactory.class,
         () -> new ConfigGuiHandler.ConfigGuiFactory((minecraft, parent) -> new ConfigScreen(parent))
      );
   }

   private static void onTick(Minecraft minecraft) {
      InspectController.tick(minecraft);
      while (Keys.INSPECT.consumeClick()) {
         if (InspectController.isActive() && Screen.hasShiftDown()) {
            InspectController.requestStop();
         } else {
            InspectController.press(minecraft, false);
         }
      }

      while (Keys.CYCLE.consumeClick()) {
         ShowcaseConfig config = ShowcaseConfig.get();
         ShowcaseAnimation next = config.animation().next();
         config.setAnimation(next);
         ShowcaseConfig.save();
         LocalPlayer player = minecraft.player;
         if (player != null) {
            player.displayClientMessage(
               new TranslatableComponent("weaponshowcase.message.animation", new TranslatableComponent(next.translationKey())), true
            );
         }
      }

      while (Keys.MENU.consumeClick()) {
         if (minecraft.screen == null) {
            minecraft.setScreen(new ConfigScreen(null));
         }
      }
   }
}
