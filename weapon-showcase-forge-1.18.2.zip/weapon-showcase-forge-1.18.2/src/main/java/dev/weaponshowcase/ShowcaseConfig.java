package dev.weaponshowcase;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.weaponshowcase.anim.ShowcaseAnimation;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.util.Mth;
import net.minecraftforge.fml.loading.FMLPaths;

/** User settings, stored as weaponshowcase.json in the config folder. */
public final class ShowcaseConfig {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static ShowcaseConfig instance;

   private String animation = ShowcaseAnimation.SHOWCASE.name();
   private boolean randomAnimation = false;
   private float speed = 1.0F;
   private float intensity = 1.0F;
   private boolean toolsOnly = false;
   private boolean cancelOnSwing = true;
   private boolean allowEmptyHand = true;
   private boolean loop = true;
   private boolean showArm = true;
   private float handX = 0.0F;
   private float handY = 0.0F;
   private float handSeparation = 0.0F;
   private boolean handFovEnabled = false;
   private float handFov = 70.0F;
   private boolean worldFovEnabled = false;
   private float worldFov = 70.0F;

   private static Path file() {
      return FMLPaths.CONFIGDIR.get().resolve("weaponshowcase.json");
   }

   public static synchronized ShowcaseConfig get() {
      if (instance == null) {
         instance = load();
      }

      return instance;
   }

   private static ShowcaseConfig load() {
      Path path = file();
      if (Files.isRegularFile(path)) {
         try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            ShowcaseConfig loaded = GSON.fromJson(reader, ShowcaseConfig.class);
            if (loaded != null) {
               loaded.sanitize();
               return loaded;
            }
         } catch (Exception var6) {
            // Corrupt or unreadable file: fall back to defaults and overwrite it on the next save.
         }
      }

      return new ShowcaseConfig();
   }

   public static synchronized void save() {
      ShowcaseConfig config = get();
      config.sanitize();
      try {
         Files.createDirectories(file().getParent());
         try (Writer writer = Files.newBufferedWriter(file(), StandardCharsets.UTF_8)) {
            GSON.toJson(config, writer);
         }
      } catch (IOException var5) {
         // Settings simply will not persist this time.
      }
   }

   private void sanitize() {
      this.animation = ShowcaseAnimation.byName(this.animation).name();
      this.speed = Mth.clamp(this.speed, 0.5F, 10.0F);
      this.intensity = Mth.clamp(this.intensity, 0.5F, 1.5F);
      this.handFov = Mth.clamp(this.handFov, 30.0F, 110.0F);
      this.worldFov = Mth.clamp(this.worldFov, 30.0F, 160.0F);
      this.handX = Mth.clamp(this.handX, -0.6F, 0.6F);
      this.handY = Mth.clamp(this.handY, -0.6F, 0.6F);
      this.handSeparation = Mth.clamp(this.handSeparation, -0.3F, 1.0F);
   }

   public ShowcaseAnimation animation() {
      return ShowcaseAnimation.byName(this.animation);
   }

   public void setAnimation(ShowcaseAnimation value) {
      this.animation = value.name();
   }

   public boolean randomAnimation() {
      return this.randomAnimation;
   }

   public void setRandomAnimation(boolean value) {
      this.randomAnimation = value;
   }

   public float speed() {
      return this.speed;
   }

   public void setSpeed(float value) {
      this.speed = Mth.clamp(value, 0.5F, 10.0F);
   }

   public float intensity() {
      return this.intensity;
   }

   public void setIntensity(float value) {
      this.intensity = Mth.clamp(value, 0.5F, 1.5F);
   }

   public boolean toolsOnly() {
      return this.toolsOnly;
   }

   public void setToolsOnly(boolean value) {
      this.toolsOnly = value;
   }

   public boolean cancelOnSwing() {
      return this.cancelOnSwing;
   }

   public void setCancelOnSwing(boolean value) {
      this.cancelOnSwing = value;
   }

   public boolean allowEmptyHand() {
      return this.allowEmptyHand;
   }

   public void setAllowEmptyHand(boolean value) {
      this.allowEmptyHand = value;
   }

   public boolean handFovEnabled() {
      return this.handFovEnabled;
   }

   public void setHandFovEnabled(boolean value) {
      this.handFovEnabled = value;
   }

   public float handFov() {
      return this.handFov;
   }

   public void setHandFov(float value) {
      this.handFov = Mth.clamp(value, 30.0F, 110.0F);
   }

   public boolean worldFovEnabled() {
      return this.worldFovEnabled;
   }

   public void setWorldFovEnabled(boolean value) {
      this.worldFovEnabled = value;
   }

   public float worldFov() {
      return this.worldFov;
   }

   public void setWorldFov(float value) {
      this.worldFov = Mth.clamp(value, 30.0F, 160.0F);
   }

   public boolean loop() {
      return this.loop;
   }

   public void setLoop(boolean value) {
      this.loop = value;
   }

   public boolean showArm() {
      return this.showArm;
   }

   public void setShowArm(boolean value) {
      this.showArm = value;
   }

   public float handX() {
      return this.handX;
   }

   public void setHandX(float value) {
      this.handX = Mth.clamp(value, -0.6F, 0.6F);
   }

   public float handY() {
      return this.handY;
   }

   public void setHandY(float value) {
      this.handY = Mth.clamp(value, -0.6F, 0.6F);
   }

   public float handSeparation() {
      return this.handSeparation;
   }

   public void setHandSeparation(float value) {
      this.handSeparation = Mth.clamp(value, -0.3F, 1.0F);
   }

   public void resetHandPosition() {
      this.handX = 0.0F;
      this.handY = 0.0F;
      this.handSeparation = 0.0F;
   }
}
