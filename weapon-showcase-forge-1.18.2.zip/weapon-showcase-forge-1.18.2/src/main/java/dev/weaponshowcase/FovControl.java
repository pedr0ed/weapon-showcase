package dev.weaponshowcase;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderLevelLastEvent;
import net.minecraftforge.event.TickEvent;

/**
 * Overrides the field of view for the world and for the first-person hand and item.
 *
 * Minecraft asks for the FOV twice per frame (world, then hand) and Forge's event does not say which is which, but
 * RenderLevelLastEvent fires right before the hand pass, so the first FOV request after it is the hand's.
 */
public final class FovControl {
   private static boolean handPass;

   private FovControl() {
   }

   public static void onRenderTick(TickEvent.RenderTickEvent event) {
      if (event.phase == TickEvent.Phase.START) {
         handPass = false;
      }
   }

   public static void onRenderLevelLast(RenderLevelLastEvent event) {
      handPass = true;
   }

   public static void onFieldOfView(EntityViewRenderEvent.FieldOfView event) {
      ShowcaseConfig config = ShowcaseConfig.get();
      if (handPass) {
         handPass = false;
         if (config.handFovEnabled()) {
            event.setFOV((double)config.handFov());
         }

         return;
      }

      if (config.worldFovEnabled()) {
         // Scale instead of replacing, so vanilla's sprint, bow and underwater FOV effects keep working.
         double vanilla = Minecraft.getInstance().options.fov;
         if (vanilla > 0.0) {
            event.setFOV(event.getFOV() * (double)config.worldFov() / vanilla);
         }
      }
   }
}
