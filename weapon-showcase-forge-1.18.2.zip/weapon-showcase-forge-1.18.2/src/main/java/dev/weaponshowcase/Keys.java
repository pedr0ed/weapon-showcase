package dev.weaponshowcase;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public final class Keys {
   private static final String CATEGORY = "key.categories.weaponshowcase";
   public static final KeyMapping INSPECT = new KeyMapping("key.weaponshowcase.inspect", 82, CATEGORY);
   public static final KeyMapping CYCLE = new KeyMapping("key.weaponshowcase.cycle", InputConstants.UNKNOWN.getValue(), CATEGORY);
   public static final KeyMapping MENU = new KeyMapping("key.weaponshowcase.menu", InputConstants.UNKNOWN.getValue(), CATEGORY);

   private Keys() {
   }

   public static KeyMapping[] all() {
      return new KeyMapping[]{INSPECT, CYCLE, MENU};
   }
}
